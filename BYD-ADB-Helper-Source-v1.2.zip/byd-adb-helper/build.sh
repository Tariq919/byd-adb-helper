#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT to an Android SDK with platform android-35}"
BUILD_TOOLS_DIR="${BUILD_TOOLS_DIR:-$ANDROID_SDK_ROOT/build-tools/35.0.0}"
ANDROID_JAR="${ANDROID_JAR:-$ANDROID_SDK_ROOT/platforms/android-35/android.jar}"
mkdir -p build/classes build/dex dist .signing
if [[ -n "${ECJ_JAR:-}" ]]; then
  java -jar "$ECJ_JAR" -1.8 -encoding UTF-8 -nowarn -classpath "$ANDROID_JAR" -d build/classes src/om/tariq/adbhelper/*.java
  java -jar "$ECJ_JAR" -1.8 -encoding UTF-8 -nowarn -classpath build/classes -d build/test-classes tests/*.java
else
  javac -source 8 -target 8 -encoding UTF-8 -classpath "$ANDROID_JAR" -d build/classes src/om/tariq/adbhelper/*.java
  javac -source 8 -target 8 -classpath build/classes -d build/test-classes tests/*.java
fi
java -cp build/classes:build/test-classes StatusLogicTest
java -cp build/classes:build/test-classes LocalCodeTest
java -cp build/classes:build/test-classes AdbProbeTest
"$BUILD_TOOLS_DIR/aapt2" compile --dir res -o build/resources.zip
"$BUILD_TOOLS_DIR/aapt2" link -o build/unsigned.apk -I "$ANDROID_JAR" --manifest AndroidManifest.xml build/resources.zip
find build/classes -name '*.class' -print > build/classes.list
"$BUILD_TOOLS_DIR/d8" --lib "$ANDROID_JAR" --min-api 26 --output build/dex @build/classes.list
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
with ZipFile('build/unsigned.apk','a',ZIP_DEFLATED) as z:
    for p in sorted(Path('build/dex').glob('*.dex')): z.write(p,p.name)
PY
"$BUILD_TOOLS_DIR/zipalign" -f 4 build/unsigned.apk build/aligned.apk
if [[ ! -f .signing/release.jks ]]; then
  keytool -genkeypair -keystore .signing/release.jks -alias adbhelper -keyalg RSA -keysize 3072 -validity 10000 -storepass local-build-only -keypass local-build-only -dname "CN=ADB Helper Local Build"
fi
"$BUILD_TOOLS_DIR/apksigner" sign --ks .signing/release.jks --ks-key-alias adbhelper --ks-pass pass:local-build-only --key-pass pass:local-build-only --out dist/BYD-ADB-Helper-v1.2.apk build/aligned.apk
"$BUILD_TOOLS_DIR/apksigner" verify --verbose dist/BYD-ADB-Helper-v1.2.apk
sha256sum dist/BYD-ADB-Helper-v1.2.apk > dist/SHA256SUMS
echo 'Built dist/BYD-ADB-Helper-v1.2.apk'
