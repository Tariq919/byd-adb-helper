package om.tariq.adbhelper;

/** Pure status rules: a setting or an open port is never proof of an authorised session. */
public final class StatusLogic {
    private StatusLogic() {}
    public static String summarize(String adb, String wifi, boolean port, boolean secure) {
        if (port) return "منفذ محلي يستجيب — يلزم اختبار اتصال ADB";
        if ("1".equals(adb) || "1".equals(wifi)) return "الإعداد مفعّل — الاتصال غير مؤكد";
        if (secure) return "صلاحية التعديل متاحة — جرّب التفعيل";
        return "التفعيل غير مؤكد — ابدأ بالمحاولة";
    }
    public static boolean safeCandidate(String pkg, String activity) {
        String p = pkg.toLowerCase(java.util.Locale.ROOT);
        String a = activity.toLowerCase(java.util.Locale.ROOT);
        if (!(p.contains("byd") || p.equals("com.android.settings"))) return false;
        String all = p + "/" + a;
        if (all.matches(".*(reset|wipe|upgrade|flash|calibr|recovery|format|burn|aging|factory|update).*")) return false;
        return all.contains("development") || a.contains("developer") || a.contains("adb") || a.contains("wirelessdebug");
    }
}
