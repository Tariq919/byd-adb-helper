package om.tariq.adbhelper;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Independent implementation of the publicly documented BYD Secret algorithm.
 * Only applicable if the OEM UI itself accepts local codes. No QR authorisation. */
public final class LocalCode {
    private LocalCode() {}
    private static String at(Date date,String pattern) {
        SimpleDateFormat fmt=new SimpleDateFormat(pattern,Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
        return fmt.format(date);
    }
    public static String generate(String suffix,Date time) throws Exception {
        if(suffix==null||!suffix.matches("[0-9]{6}"))throw new IllegalArgumentException("Exactly six ASCII digits required");
        String key=suffix+at(time,"MMddyyyyHH");
        String plain=at(time,"yyyyddMMHH")+suffix;
        Cipher cipher=Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key.getBytes(StandardCharsets.US_ASCII),"AES"),new IvParameterSpec("1995020213467928".getBytes(StandardCharsets.US_ASCII)));
        String encrypted=Base64.getEncoder().encodeToString(cipher.doFinal(plain.getBytes(StandardCharsets.US_ASCII)));
        String date=at(time,"MMddHH");
        byte[] mixed=new byte[6];
        for(int i=0;i<6;i++){
            int first=suffix.charAt(i)-'0';
            int second=first+date.charAt(i)-'0';
            mixed[i]=(byte)(encrypted.charAt(first)^encrypted.charAt(second));
        }
        String encoded=Base64.getEncoder().encodeToString(mixed);
        StringBuilder code=new StringBuilder();
        for(int i=0;i<encoded.length()&&code.length()<6;i++){
            char c=encoded.charAt(i);
            if((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9'))code.append(c);
        }
        while(code.length()<6)code.append('B');
        return code.toString().toUpperCase(Locale.US);
    }
}
