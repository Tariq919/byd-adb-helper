import om.tariq.adbhelper.LocalCode;
import java.text.SimpleDateFormat;
import java.util.*;
public final class LocalCodeTest {
    static void assertCodes(String id,String at,String[] expected)throws Exception{
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date t=f.parse(at);
        for(int i=0;i<5;i++)if(!expected[i].equals(LocalCode.generate(id,new Date(t.getTime()+(i-2)*3600000L))))throw new AssertionError(id+" hour "+i);
    }
    public static void main(String[] args)throws Exception{
        assertCodes("123456","2026-08-02T23:07:00Z",new String[]{"ADUAVG","ADAAUQ","AD0AMQ","ACSAUA","AE8ABW"});
        assertCodes("000000","2026-01-01T00:00:00Z",new String[]{"AEQARA","ABWAHA","ADEAMQ","ABOAGG","ADQAND"});
        assertCodes("999999","2026-12-31T15:59:00Z",new String[]{"OXO8OX","GHKCGH","SKBRSK","AD8APW","ABMAEW"});
        assertCodes("654321","2026-06-15T04:30:00Z",new String[]{"ABSVZF","AASHYW","AEZAGQ","AECCEC","ADLRAW"});
        assertCodes("100200","2026-03-08T16:00:00Z",new String[]{"ABIAFG","AE8ADW","AH8ALG","ADCAXG","ADOABQ"});
        assertCodes("246810","2025-11-20T10:10:00Z",new String[]{"CVLBAB","RS0WAH","EROUAG","PK1AAB","GZNUAD"});
        assertCodes("112233","2026-02-28T16:00:00Z",new String[]{"ACOOU2","ABOVFD","AEEADA","AACAXA","AB0AJG"});
        assertCodes("500001","2026-07-04T12:00:00Z",new String[]{"AC0AMC","ADAAMJ","AFCAHJ","ACKAAY","AGCAMW"});
        assertCodes("000001","2026-08-03T00:33:41Z",new String[]{"ADOARQ","ABKADG","ACCAPG","ADCAAW","ACOABC"});
        try{LocalCode.generate("12",new Date());throw new AssertionError("Short input");}catch(IllegalArgumentException ok){}
        try{LocalCode.generate("١٢٣٤٥٦",new Date());throw new AssertionError("Non-ASCII input");}catch(IllegalArgumentException ok){}
        System.out.println("PASS: 45 published code vectors + 2 invalid input cases");
    }
}
