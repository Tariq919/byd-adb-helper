package om.tariq.adbhelper;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.*;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final int BG=0xff0b1526, CARD=0xff14243b, TEXT=0xffedf4ff, MUTED=0xffa9bbd2, TEAL=0xff43d5d0;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayList<Button> controls = new ArrayList<>();
    private final StringBuilder history = new StringBuilder();
    private LinearLayout root;
    private TextView status, details, result;
    private volatile boolean busy=false;
    private volatile String report="لم يكتمل الفحص بعد.";
    private String pendingExport;
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(26),dp(20),dp(26),dp(24));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root); setContentView(scroll);
        label("مساعد ADB",32,TEXT,true);
        label("BYD • الإصدار 1.1 • بحث مسار المصنع",15,TEAL,false);
        label("شغّل الأداة والسيارة متوقفة على P. نجاح التفعيل يعتمد على حماية نظام الشاشة.",17,MUTED,false);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18),dp(14),dp(18),dp(14)); card.setBackground(background(CARD,18));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(14),0,dp(8)); root.addView(card,cp);
        status=text("جارٍ قراءة الحالة…",21,TEAL,true); card.addView(status);
        details=text("",16,TEXT,false); details.setTextDirection(View.TEXT_DIRECTION_LTR); details.setGravity(Gravity.LEFT); card.addView(details);
        result=label("ابدأ بمداخل BYD الأصلية. إذا ظهر تحقق QR فقط، صدّر ملفات الدراسة لفحص إصدار شاشتك.",17,MUTED,false);
        button("١  مداخل BYD الأصلية",true,()->nativeRoutes());
        row("٢  حساب رمز محلي",()->localCodeDialog(),"٣  تصدير ملفات الدراسة",()->exportStudy());
        button("محاولة الكتابة المباشرة السابقة",false,()->new AlertDialog.Builder(this).setTitle("محاولة التفعيل")
            .setMessage("سيحاول التطبيق تغيير إعدادات تطوير Android وADB السلكي واللاسلكي، ثم خصيصتي ADB المعروفتين في BYD. قد يرفض النظام هذه المحاولات. لا يغيّر إعدادات القيادة. هل تبدأ؟")
            .setPositiveButton("ابدأ",(d,w)->activate()).setNegativeButton("إلغاء",null).show());
        row("٢  إعدادات المطوّر",()->openSettings("android.settings.APPLICATION_DEVELOPMENT_SETTINGS"),"التصحيح اللاسلكي",()->openWireless());
        row("٣  قوائم BYD المتاحة",()->findByd(),"إعدادات USB",()->openSettings("android.settings.USB_SETTINGS"));
        row("تحديث الحالة",()->scan(),"عرض التقرير وحفظه",()->showReport());
        row("مساعدة رمز الصيانة",()->showServiceHelp(),"الإعدادات العامة",()->openSettings(Settings.ACTION_SETTINGS));
        label("لا يمنح التطبيق نفسه صلاحيات النظام. إذا ظهرت رسالة منع، افتح قائمة التطوير أو اعتمد التفعيل من الصيانة، ثم أعد الفحص. ظهور إعداد مفعّل لا يثبت وجود اتصال ADB مصرح به.",15,MUTED,false);
        scan();
    }
    private GradientDrawable background(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,dp(4),0,dp(4)); t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    private TextView label(String s,int size,int color,boolean bold) { TextView t=text(s,size,color,bold); root.addView(t); return t; }
    private Button makeButton(String title,boolean primary,Runnable action) {
        Button b=new Button(this); b.setText(title); b.setTextSize(17); b.setAllCaps(false); b.setMinHeight(dp(58)); b.setPadding(dp(10),dp(8),dp(10),dp(8));
        b.setTextColor(primary?BG:TEXT); b.setBackground(background(primary?TEAL:CARD,12)); b.setOnClickListener(v->action.run()); controls.add(b); return b;
    }
    private void button(String title,boolean primary,Runnable action) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(8),0,dp(4)); root.addView(makeButton(title,primary,action),p); }
    private void row(String a,Runnable ra,String b,Runnable rb) {
        if(getResources().getConfiguration().screenWidthDp<540) { button(a,false,ra); button(b,false,rb); return; }
        LinearLayout line=new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.setMargins(dp(4),dp(6),dp(4),dp(6));
        line.addView(makeButton(a,false,ra),p); line.addView(makeButton(b,false,rb),new LinearLayout.LayoutParams(p)); root.addView(line);
    }
    private void dispatch(Runnable task) { if(busy)return; busy=true; for(Button b:controls)b.setEnabled(false); worker.execute(()->{try{task.run();}catch(Exception e){log("Unexpected: "+brief(e));}finally{runOnUiThread(()->{if(isDestroyed())return;busy=false; for(Button b:controls)b.setEnabled(true);});}}); }
    private synchronized void log(String s) { history.append(new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date())).append(" ").append(s).append('\n'); if(history.length()>24000)history.delete(0,history.length()-20000); }
    private String brief(Exception e) { String s=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage()); return s.length()>350?s.substring(0,350):s; }
    private String setting(String key) { try {String v=Settings.Global.getString(getContentResolver(),key); return v==null?"unset":v;}catch(Exception e){return "unreadable";} }
    private boolean secure() { return checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS)==PackageManager.PERMISSION_GRANTED; }
    private String command(String... args) {
        java.lang.Process p=null; try { p=new ProcessBuilder(args).redirectErrorStream(true).start(); if(!p.waitFor(1200,TimeUnit.MILLISECONDS)){p.destroy(); return "timeout";}
            ByteArrayOutputStream out=new ByteArrayOutputStream(); InputStream in=p.getInputStream(); byte[] buf=new byte[512]; int n; while((n=in.read(buf))!=-1&&out.size()<3000)out.write(buf,0,n);
            return "exit="+p.exitValue()+" "+out.toString("UTF-8").trim();
        } catch(Exception e){return brief(e);} finally {if(p!=null)p.destroy();}
    }
    private String prop(String key) { String s=command("/system/bin/getprop",key); return s.startsWith("exit=0 ")?s.substring(7).trim():"unreadable"; }
    private boolean localPort() { try(Socket s=new Socket()){s.connect(new InetSocketAddress("127.0.0.1",5555),350);return true;}catch(Exception e){return false;} }
    private void scan() { dispatch(()->refreshStatus()); }
    private void refreshStatus() {
        String a=setting("adb_enabled"), w=setting("adb_wifi_enabled"), dev=setting("development_settings_enabled");
        boolean perm=secure(), port=localPort();
        String wireless=prop("persist.sys.adb.wiress.enable"), connect=prop("sys.connect.adb.wiress");
        String state=StatusLogic.summarize(a,w,port,perm);
        if(!port && ("true".equals(wireless)||"1".equals(connect)))state="إعداد BYD اللاسلكي مفعّل — الاتصال غير مؤكد";
        final String displayState=state;
        String block="Android "+Build.VERSION.RELEASE+" • API "+Build.VERSION.SDK_INT+"\n"+Build.MANUFACTURER+" / "+Build.MODEL+"\nUSB ADB: "+a+"  |  Wireless: "+w+"\nWRITE_SECURE_SETTINGS: "+(perm?"granted":"not granted")+"\nLocal TCP 5555: "+(port?"responds (unverified)":"not reachable");
        StringBuilder r=new StringBuilder("BYD ADB Helper 1.1.0\n");
        r.append("Time: ").append(new Date()).append("\nAndroid: ").append(Build.VERSION.RELEASE).append(" API ").append(Build.VERSION.SDK_INT)
            .append("\nManufacturer/model: ").append(Build.MANUFACTURER).append('/').append(Build.MODEL)
            .append("\nBuild display: ").append(Build.DISPLAY)
            .append("\nDevice: ").append(Build.DEVICE).append("\nHardware: ").append(Build.HARDWARE)
            .append("\nFirmware property: ").append(prop("persist.sys.version"))
            .append("\nBoard platform: ").append(prop("ro.board.platform"))
            .append("\nFirmware in supplied reference: 23.1.83.2602236.1 (not detected from reference)\n")
            .append("development_settings_enabled=").append(dev).append("\nadb_enabled=").append(a).append("\nadb_wifi_enabled=").append(w)
            .append("\npersist.sys.adb.wiress.enable=").append(wireless).append("\nsys.connect.adb.wiress=").append(connect)
            .append("\nsecure_permission=").append(perm).append("\nlocal_port_5555=").append(port)
            .append("\nAn open local port is not proof of ADB or authorisation.\n\nActivity discovery:\n");
        for(ActivityInfo i:candidates()) r.append(i.packageName).append('/').append(i.name).append(" exported=").append(i.exported).append(" enabled=").append(i.enabled).append(" permission=").append(i.permission).append('\n');
        synchronized(this){r.append("\nActions:\n").append(history);} report=r.toString();
        runOnUiThread(()->{if(isDestroyed())return;status.setText(displayState);details.setText(block);});
    }
    private void put(String key,int value) {
        try { boolean accepted=Settings.Global.putInt(getContentResolver(),key,value); String actual=setting(key); log(key+" write_return="+accepted+" readback="+actual); }
        catch(Exception e){log(key+" blocked: "+brief(e));}
    }
    private void activate() {
        result.setText("جارٍ محاولة التفعيل وقراءة النتائج…");
        dispatch(()->{ put("development_settings_enabled",1); put("adb_enabled",1); put("adb_wifi_enabled",1);
            log("BYD property attempt: "+command("/system/bin/setprop","persist.sys.adb.wiress.enable","true"));
            log("BYD connect attempt: "+command("/system/bin/setprop","sys.connect.adb.wiress","1"));
            refreshStatus(); boolean enabled="1".equals(setting("adb_enabled"))||"1".equals(setting("adb_wifi_enabled"))||"true".equals(prop("persist.sys.adb.wiress.enable"))||"1".equals(prop("sys.connect.adb.wiress"));
            runOnUiThread(()->{if(isDestroyed())return;result.setText(enabled?"يوجد إعداد ADB مفعّل. اختبر الاتصال من الكمبيوتر؛ لم يُثبت التفويض بعد.":"لم يتأكد تفعيل ADB. افتح إعدادات المطوّر أو قوائم BYD، ثم اعرض التقرير.");});
        });
    }
    private void openSettings(String action) { launch(new Intent(action)); }
    private boolean launch(Intent i) {try {startActivity(i);log("Opened: "+i.toUri(0));return true;}catch(Exception e){log("Open blocked: "+brief(e));new AlertDialog.Builder(this).setTitle("القائمة غير متاحة").setMessage("النظام لم يسمح بفتح هذه الصفحة. جرّب قوائم BYD أو مساعدة رمز الصيانة.").setPositiveButton("حسنًا",null).show();return false;} }
    private void openWireless() {
        Intent i=new Intent("android.settings.WIRELESS_DEBUGGING_SETTINGS");
        if(i.resolveActivity(getPackageManager())!=null) {launch(i);return;}
        i=new Intent().setComponent(new ComponentName("com.android.settings","com.android.settings.Settings$WirelessDebuggingActivity"));
        if(i.resolveActivity(getPackageManager())!=null) {launch(i);return;}
        log("Wireless page absent; using developer settings"); openSettings("android.settings.APPLICATION_DEVELOPMENT_SETTINGS");
    }
    private ArrayList<ActivityInfo> candidates() {
        ArrayList<ActivityInfo> found=new ArrayList<>();
        try { for(PackageInfo p:getPackageManager().getInstalledPackages(PackageManager.GET_ACTIVITIES)) {
            if(p.activities==null||p.applicationInfo==null||!p.applicationInfo.enabled)continue;
            if((p.applicationInfo.flags&ApplicationInfo.FLAG_SYSTEM)==0)continue;
            for(ActivityInfo a:p.activities) if(StatusLogic.safeCandidate(a.packageName,a.name))found.add(a);
        }} catch(Exception e){log("Discovery: "+brief(e));}
        Collections.sort(found,(a,b)->(a.packageName+"/"+a.name).compareTo(b.packageName+"/"+b.name)); return found;
    }
    private void findByd() {dispatch(()->{
        ArrayList<ActivityInfo> usable=new ArrayList<>();for(ActivityInfo a:candidates())if(a.enabled&&a.exported&&(a.permission==null||checkSelfPermission(a.permission)==PackageManager.PERMISSION_GRANTED))usable.add(a);
        runOnUiThread(()->{if(isDestroyed())return;
            if(usable.isEmpty()){new AlertDialog.Builder(this).setTitle("لم نجد قائمة تطوير مسموحة").setMessage("قد تكون القائمة محمية أو غير ظاهرة للتطبيقات. استخدم مساعدة رمز الصيانة. يتضمن التقرير نتائج الفحص المتاحة.").setPositiveButton("حسنًا",null).show();return;}
            String[] names=new String[usable.size()];for(int n=0;n<names.length;n++){ActivityInfo a=usable.get(n);names[n]=a.packageName+"\n"+a.name;}
            new AlertDialog.Builder(this).setTitle("اختر قائمة التطوير لفتحها").setItems(names,(d,n)->{ActivityInfo a=usable.get(n);launch(new Intent().setComponent(new ComponentName(a.packageName,a.name)));}).setNegativeButton("إلغاء",null).show();
        });
    });}
    private void copy(String s) { ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("ADB helper",s));Toast.makeText(this,"تم النسخ",Toast.LENGTH_SHORT).show(); }
    private void showServiceHelp() {
        new AlertDialog.Builder(this).setTitle("قائمة الصيانة المخفية").setMessage("اربط الهاتف بالسيارة عبر Bluetooth، ثم افتح لوحة الاتصال في شاشة السيارة وأدخل:\n\n*#91532547#*\n\nقد تظهر كلمة مرور أو صفحة QR تحتاج اعتمادًا من جهة صيانة مناسبة. التطبيق لا يولّد اعتماد BYD ولا يتجاوز التحقق. عند فتح قائمة التطوير فعّل Wireless ADB وUSB debugging فقط.")
            .setPositiveButton("نسخ الرمز",(d,w)->copy("*#91532547#*")).setNegativeButton("إغلاق",null).show();
    }
    private void nativeRoutes() {
        String[] labels={"التحقق برمز محلي — INPUT_CODE_VERIFICATION","المدخل العام — VERIFICATION","إعدادات ADB الأصلية — ADB_SETTINGS","إعدادات التطوير — DEVELOPMENT_SETTINGS","التحقق برمز QR — SCAN_CODE_VERIFICATION"};
        String[] suffix={"INPUT_CODE_VERIFICATION","VERIFICATION","ADB_SETTINGS","DEVELOPMENT_SETTINGS","SCAN_CODE_VERIFICATION"};
        new AlertDialog.Builder(this).setTitle("مسارات المصنع — اختبارات غير مؤكدة").setItems(labels,(dialog,index)->{
            String action="android.byd.intent.action."+suffix[index];
            ArrayList<ActivityInfo> list=new ArrayList<>();
            try {
                for(ResolveInfo ri:getPackageManager().queryIntentActivities(new Intent(action),0)){
                    ActivityInfo a=ri.activityInfo;
                    if(a!=null&&a.packageName.toLowerCase(Locale.ROOT).contains("byd")&&a.exported&&a.enabled&&(a.permission==null||checkSelfPermission(a.permission)==PackageManager.PERMISSION_GRANTED))list.add(a);
                }
                String[] tails={"VerificationActivity","JumpActivity","ADBSettingsActivity","DevelopmentSettingsActivity","ScanCodeActivity"};
                for(ActivityInfo a:candidates())if(a.name.endsWith("."+tails[index])&&a.enabled&&a.exported&&(a.permission==null||checkSelfPermission(a.permission)==PackageManager.PERMISSION_GRANTED)){
                    boolean duplicate=false;for(ActivityInfo old:list)if(old.name.equals(a.name)&&old.packageName.equals(a.packageName))duplicate=true;
                    if(!duplicate)list.add(a);
                }
            }catch(Exception e){log("Native route lookup: "+brief(e));}
            if(list.isEmpty()){
                log("Native route absent or restricted: "+action);
                new AlertDialog.Builder(this).setTitle("المسار غير متاح للتطبيق").setMessage("لم يظهر مدخل مصنع مسموح لهذا المسار. لا يعني ذلك غيابه من النظام. صدّر ملفات الدراسة لفحص تطبيق شاشتك نفسه.").setPositiveButton("حسنًا",null).show();return;
            }
            String[] names=new String[list.size()];for(int n=0;n<names.length;n++)names[n]=list.get(n).packageName+"\n"+list.get(n).name;
            new AlertDialog.Builder(this).setTitle("اختيار المدخل الأصلي").setItems(names,(d,n)->{ActivityInfo a=list.get(n);launch(new Intent(action).setComponent(new ComponentName(a.packageName,a.name)));}).setNegativeButton("إلغاء",null).show();
        }).setNegativeButton("إغلاق",null).show();
    }
    private void localCodeDialog() {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(10),dp(20),dp(10));
        TextView note=text("هذا الحساب ينفع فقط إذا قبلت صفحة المصنع رمزًا محليًا. لا يفتح QR ولا يرسل بيانات. أدخل آخر ٦ أرقام من IMEI يدويًا بالأرقام الإنجليزية، ثم وقت التحقق بتوقيت الصين. لا تكرر المحاولات عشوائيًا.",16,TEXT,false);box.addView(note);
        EditText suffix=new EditText(this);suffix.setHint("آخر 6 أرقام من IMEI");suffix.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);suffix.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});suffix.setTextDirection(View.TEXT_DIRECTION_LTR);box.addView(suffix);
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH",Locale.US);fmt.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));fmt.setLenient(false);
        EditText clock=new EditText(this);clock.setSingleLine(true);clock.setText(fmt.format(new Date()));clock.setHint("yyyy-MM-dd HH — China UTC+8");clock.setTextDirection(View.TEXT_DIRECTION_LTR);box.addView(clock);
        TextView answer=text("",22,TEAL,true);answer.setTextDirection(View.TEXT_DIRECTION_LTR);answer.setTextIsSelectable(true);box.addView(answer);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("حساب محلي — دون اعتماد QR").setView(box).setPositiveButton("حساب",null).setNegativeButton("إغلاق",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{
            String identifier=suffix.getText().toString().trim(), timeText=clock.getText().toString().trim();
            if(!timeText.matches("[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}"))throw new IllegalArgumentException("التاريخ: yyyy-MM-dd HH");
            Date at=fmt.parse(timeText);String code=LocalCode.generate(identifier,at);
            answer.setText(code+"\n"+timeText+" UTC+8\nالقبول على هذا الإصدار غير مؤكد");
        }catch(Exception e){answer.setText("تحقق من الأرقام والوقت المدخل.");}}));dialog.show();
    }
    private void exportStudy() {
        new AlertDialog.Builder(this).setTitle("استخراج تطبيقات المصنع للدراسة").setMessage("ينشئ ZIP من كود تطبيق التطوير وخدمة التحقق المثبتين على هذه الشاشة، مع إصداراتهما ومداخل التشغيل وبصمة شهادة التوقيع. لا يقرأ بيانات حسابك أو VIN أو IMEI أو مفاتيح أو رموز الدخول، ولا يرفع الملف. لا يحتاج إلى ADB. إذا منع النظام قراءة APK فسيسجل ذلك. اختر USB أو مجلدًا يمكنك نقل الملف منه.")
        .setPositiveButton(Build.VERSION.SDK_INT>=29?"حفظ في التنزيلات":"اختر مكان الحفظ",(d,w)->{if(Build.VERSION.SDK_INT>=29)saveStudyToDownloads();else chooseStudyFile();})
        .setNeutralButton("اختر USB أو مجلدًا",(d,w)->chooseStudyFile()).setNegativeButton("إلغاء",null).show();
    }
    private void chooseStudyFile() {
        try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/zip").putExtra(Intent.EXTRA_TITLE,"BYD-System-Study.zip"),41);}
        catch(Exception e){Toast.makeText(this,"لا يوجد منتقي ملفات متاح؛ استخدم الحفظ في التنزيلات أو انسخ التقرير",Toast.LENGTH_LONG).show();}
    }
    private void saveStudyToDownloads() {
        if(Build.VERSION.SDK_INT<29){chooseStudyFile();return;}
        try{
            ContentValues values=new ContentValues();values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,"BYD-System-Study-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date())+".zip");values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE,"application/zip");values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/BYD-Study");values.put(android.provider.MediaStore.MediaColumns.IS_PENDING,1);
            Uri uri=getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("Downloads unavailable");writeStudy(uri,true);
        }catch(Exception e){log("Downloads unavailable: "+brief(e));chooseStudyFile();}
    }
    private boolean studyTarget(String p) {
        String lower=p.toLowerCase(Locale.ROOT);
        return lower.contains("byd")&&(lower.contains("byddevelopmenttools")||lower.endsWith(".authservice"));
    }
    private String digest(byte[] data)throws Exception {StringBuilder h=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(data))h.append(String.format(Locale.US,"%02x",b&255));return h.toString();}
    private void zipText(ZipOutputStream z,String name,String value)throws Exception {z.putNextEntry(new ZipEntry(name));z.write(value.getBytes("UTF-8"));z.closeEntry();}
    private void writeStudy(Uri destination) {writeStudy(destination,false);}
    private void writeStudy(Uri destination,boolean pendingDownload) {
        dispatch(()->{int exported=0,failed=0;StringBuilder index=new StringBuilder("BYD-System-Study 1.1.0\nCode-only OEM APK export; no account/user files.\n\n");
            try(OutputStream output=getContentResolver().openOutputStream(destination)){
                if(output==null)throw new IOException("No destination stream");
                try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(output))){
                    refreshStatus();zipText(z,"report.txt",fullReport());
                    ArrayList<PackageInfo> pkgs=new ArrayList<>(getPackageManager().getInstalledPackages(PackageManager.GET_ACTIVITIES|PackageManager.GET_SERVICES|PackageManager.GET_RECEIVERS|PackageManager.GET_SIGNATURES));
                    Collections.sort(pkgs,(a,b)->a.packageName.compareTo(b.packageName));
                    for(PackageInfo p:pkgs){
                        if(p.applicationInfo==null||(p.applicationInfo.flags&ApplicationInfo.FLAG_SYSTEM)==0)continue;
                        index.append(p.packageName).append(" version=").append(p.versionName).append(" code=").append(p.versionCode).append('\n');
                        if(!studyTarget(p.packageName))continue;
                        StringBuilder meta=new StringBuilder(p.packageName+"\nversion="+p.versionName+"\ncode="+p.versionCode+"\n");
                        if(p.signatures!=null)for(android.content.pm.Signature s:p.signatures)meta.append("certificate_sha256=").append(digest(s.toByteArray())).append('\n');
                        if(p.activities!=null)for(ActivityInfo a:p.activities)meta.append("ACTIVITY ").append(a.name).append(" exported=").append(a.exported).append(" enabled=").append(a.enabled).append(" permission=").append(a.permission).append('\n');
                        if(p.services!=null)for(ServiceInfo a:p.services)meta.append("SERVICE ").append(a.name).append(" exported=").append(a.exported).append(" permission=").append(a.permission).append('\n');
                        if(p.receivers!=null)for(ActivityInfo a:p.receivers)meta.append("RECEIVER ").append(a.name).append(" exported=").append(a.exported).append(" permission=").append(a.permission).append('\n');
                        zipText(z,p.packageName+"/metadata.txt",meta.toString());
                        ArrayList<String> paths=new ArrayList<>();paths.add(p.applicationInfo.sourceDir);if(p.applicationInfo.splitSourceDirs!=null)Collections.addAll(paths,p.applicationInfo.splitSourceDirs);
                        for(int n=0;n<paths.size();n++){
                            File file=new File(paths.get(n));
                            if(!file.isFile()||!file.canRead()||file.length()>128L*1024*1024){failed++;index.append("APK_NOT_READABLE_OR_TOO_LARGE ").append(p.packageName).append(" part=").append(n).append('\n');continue;}
                            try(FileInputStream in=new FileInputStream(file)){
                                z.putNextEntry(new ZipEntry(p.packageName+"/"+(n==0?"base.apk":"split-"+n+".apk")));
                                byte[] buffer=new byte[32768];int count;while((count=in.read(buffer))!=-1)z.write(buffer,0,count);z.closeEntry();exported++;
                            }
                        }
                    }
                    index.append("\nExported APK parts: ").append(exported).append("\nSkipped APK parts: ").append(failed).append('\n');zipText(z,"package-inventory.txt",index.toString());
                }
                final int count=exported,skipped=failed;log("Study ZIP saved; apk_parts="+count+" skipped="+skipped);
                if(pendingDownload&&Build.VERSION.SDK_INT>=29){ContentValues done=new ContentValues();done.put(android.provider.MediaStore.MediaColumns.IS_PENDING,0);getContentResolver().update(destination,done,null,null);}
                runOnUiThread(()->{if(isDestroyed())return;new AlertDialog.Builder(this).setTitle(count>0?"تم استخراج ملفات الدراسة":"تم حفظ التقرير دون APK").setMessage((pendingDownload?"مكان الحفظ: Download/BYD-Study\n":"")+"أجزاء APK المحفوظة: "+count+"\nالمتعذرة: "+skipped+"\n"+(count>0?"أرسل ZIP في المحادثة لفحص تطبيق إصدارك. لا ترفعه إلى مستودع عام.":"ربما تختلف أسماء حزم هذا الإصدار أو يمنع النظام قراءتها. أرسل ملف ZIP أو التقرير أولًا لمعرفة أسماء التطبيقات.")).setPositiveButton("حسنًا",null).show();});
            }catch(Exception e){log("Study export failed: "+brief(e));if(pendingDownload)try{getContentResolver().delete(destination,null,null);}catch(Exception ignored){}runOnUiThread(()->{if(!isDestroyed())Toast.makeText(this,"تعذر إكمال ZIP؛ لا تعتبر الملف مكتملًا. انسخ التقرير النصي.",Toast.LENGTH_LONG).show();});}
        });
    }
    private String fullReport() { synchronized(this) {return report+"\nLatest actions:\n"+history;} }
    private void showReport() {
        ScrollView sc=new ScrollView(this);TextView t=new TextView(this);t.setText(fullReport());t.setTextSize(14);t.setPadding(dp(16),dp(16),dp(16),dp(16));t.setTextIsSelectable(true);t.setTextDirection(View.TEXT_DIRECTION_LTR);t.setTypeface(Typeface.MONOSPACE);sc.addView(t);
        new AlertDialog.Builder(this).setTitle("تقرير الفحص — دون IMEI أو VIN").setView(sc).setPositiveButton("حفظ TXT",(d,w)->exportReport()).setNeutralButton("نسخ",(d,w)->copy(fullReport())).setNegativeButton("إغلاق",null).show();
    }
    private void exportReport() {
        pendingExport=fullReport();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/plain").putExtra(Intent.EXTRA_TITLE,"BYD-ADB-report.txt");
        try{startActivityForResult(i,40);}catch(Exception e){pendingExport=null;Toast.makeText(this,"لا يوجد منتقي ملفات؛ استخدم نسخ التقرير",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int code,Intent data) {super.onActivityResult(request,code,data);
        if(request==41&&code==RESULT_OK&&data!=null&&data.getData()!=null){writeStudy(data.getData());return;}
        if(request==40){String value=pendingExport;pendingExport=null;if(code!=RESULT_OK||data==null||data.getData()==null||value==null)return;
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())) {if(out==null)throw new IOException("No output stream");out.write(value.getBytes("UTF-8"));Toast.makeText(this,"تم حفظ التقرير",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"تعذر الحفظ: "+brief(e),Toast.LENGTH_LONG).show();}}
    }
    @Override protected void onResume(){super.onResume();if(status!=null&&!busy)scan();}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
