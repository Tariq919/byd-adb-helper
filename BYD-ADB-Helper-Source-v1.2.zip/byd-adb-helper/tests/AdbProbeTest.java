import om.tariq.adbhelper.AdbProbe;
import java.nio.*;
public final class AdbProbeTest {
    static byte[] header(int command,int arg,int size,int magic){return ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).putInt(command).putInt(arg).putInt(0).putInt(size).putInt(0).putInt(magic).array();}
    static void check(boolean ok){if(!ok)throw new AssertionError();}
    public static void main(String[] args){
        check(AdbProbe.inspectHeader(header(0x48545541,1,20,0xb7abaabe)).startsWith("ADB_AUTH_CHALLENGE"));
        check(AdbProbe.inspectHeader(header(0x4e584e43,0x01000001,32,0xb1a7b1bc)).startsWith("ADB_CNXN_HEADER"));
        check(AdbProbe.inspectHeader(new byte[24]).equals("INVALID_HEADER"));
        check(AdbProbe.inspectHeader(new byte[2]).equals("INVALID_HEADER"));
        check(AdbProbe.inspectHeader(header(0x48545541,1,90000,0xb7abaabe)).equals("INVALID_HEADER"));
        check(AdbProbe.inspectHeader(header(0x48545541,3,20,0xb7abaabe)).equals("UNEXPECTED_REPLY"));
        System.out.println("PASS: 6 local ADB response classification checks");
    }
}
