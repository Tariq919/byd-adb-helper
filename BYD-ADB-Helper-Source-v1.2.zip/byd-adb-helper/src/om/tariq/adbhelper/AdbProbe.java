package om.tariq.adbhelper;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;

/** A single local ADB greeting. Never sends keys, shell commands or authorisation. */
public final class AdbProbe {
    private AdbProbe() {}
    public static String local() {
        try(Socket socket=new Socket()){
            socket.connect(new InetSocketAddress("127.0.0.1",5555),600);socket.setSoTimeout(900);
            byte[] body="host::\u0000".getBytes(StandardCharsets.US_ASCII);
            int command=0x4e584e43, checksum=0;for(byte b:body)checksum+=(b&255);
            ByteBuffer header=ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
            header.putInt(command).putInt(0x01000000).putInt(4096).putInt(body.length).putInt(checksum).putInt(command^-1);
            OutputStream out=socket.getOutputStream();out.write(header.array());out.write(body);out.flush();
            byte[] reply=new byte[24];new DataInputStream(socket.getInputStream()).readFully(reply);
            return inspectHeader(reply);
        }catch(Exception e){return "NO_ADB_REPLY: "+e.getClass().getSimpleName();}
    }
    public static String inspectHeader(byte[] bytes) {
        if(bytes==null||bytes.length!=24)return "INVALID_HEADER";
        ByteBuffer b=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        int command=b.getInt(),arg0=b.getInt();b.getInt();int size=b.getInt();b.getInt();int magic=b.getInt();
        if(magic!=(command^-1)||size<0||size>4096)return "INVALID_HEADER";
        if(command==0x48545541 && arg0==1 && size==20)return "ADB_AUTH_CHALLENGE: authentication required; not authorised";
        if(command==0x4e584e43 && (arg0==0x01000000||arg0==0x01000001))return "ADB_CNXN_HEADER: ADB greeting received; no shell tested";
        return "UNEXPECTED_REPLY";
    }
}
