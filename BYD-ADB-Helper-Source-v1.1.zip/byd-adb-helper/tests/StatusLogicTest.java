import om.tariq.adbhelper.StatusLogic;
public final class StatusLogicTest {
    static void check(boolean ok,String m){if(!ok)throw new AssertionError(m);}
    public static void main(String[] args){
        check(StatusLogic.safeCandidate("com.byd.developmenttools","com.byd.MainActivity"),"Allow real OEM development tool entry");
        check(StatusLogic.safeCandidate("com.android.settings","com.android.settings.Settings$DevelopmentSettingsDashboardActivity"),"Allow standard development UI");
        check(!StatusLogic.safeCandidate("com.byd.developmenttools","com.byd.FactoryResetActivity"),"Exclude reset even inside development package");
        check(!StatusLogic.safeCandidate("com.byd.developmenttools","com.byd.FirmwareUpgradeActivity"),"Exclude firmware changes");
        check(!StatusLogic.safeCandidate("other.app","DeveloperActivity"),"Exclude third party apps");
        check(!StatusLogic.safeCandidate("com.byd.settings","ClimateActivity"),"Exclude unrelated vehicle settings");
        check(StatusLogic.summarize("0","0",true,false).contains("يلزم اختبار"),"An unrelated listener is not authorised ADB");
        check(StatusLogic.summarize("1","0",false,false).contains("غير مؤكد"),"A setting is not confirmed connectivity");
        check(StatusLogic.summarize("unreadable","unset",false,false).contains("غير مؤكد"),"Unreadable state is not success");
        System.out.println("PASS: 9 status and activity-selection checks");
    }
}
